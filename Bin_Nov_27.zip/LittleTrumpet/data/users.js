const mongoCollections = require("../config/mongoCollections");
const Users = mongoCollections.Users;
const uuid = require("node-uuid");
const bcrypt = require("bcrypt");
const saltRounds = 16;
const Events = mongoCollections.Events;

const exportedMethods = {


    async getUserById(id){
        const usersCollection = await Users();
        const User = await usersCollection.findOne({ _id: id });
        if (!User) throw "User not found";
        return User;
    },

    async addNewUser(name, userName, password, email, phoneNumber, interests = null, age = null, securityQuestion ){

        const usersCollection = await Users();
        const hashedPassword = await bcrypt.hash(password, saltRounds);
        const newUser = {
            _id: uuid.v4(),
            name: name,
            userName: userName,
            hashedPassword: hashedPassword,
            email: email,
            phoneNumber: phoneNumber,
            rating: null,
            interests: interests,
            schedule: [],
            history: [],
            age: age,
            comments:[],
            securityQuestion: securityQuestion,
            eventsPosted: []

        }

        const newInsertInformation = await usersCollection.insertOne(newUser);
        const newId = newInsertInformation.insertedId;
        return await this.getUserById(newId);
    },




}

module.exports = exportedMethods;