const usersData = require("./users");
const eventsData = require("./events")

module.exports = {
events: eventsData,
  users: usersData
};
