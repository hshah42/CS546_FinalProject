const mongoCollections = require("../config/mongoCollections");
const Events = mongoCollections.Events;
const uuid = require("node-uuid");
const bcrypt = require("bcrypt");
const saltRounds = 16;
const Users = mongoCollections.Users;

const exportedMethods = {

    async getEventById(id){
        const eventsCollection = await Events();
        const event = await eventsCollection.findOne({ _id: id });
        if (!event) throw "Event not found";
        return event;
    },
    async addNewEvent(name, date, startTime, endTime, description ,tags, requirements, place, limit, admin, state){

        const eventsCollection = await Events();
        
        const newEvent = {
            _id: uuid.v4(),
            name: name,
            date: date,
            startTime: startTime,
            endTime: endTime,
            description: description,
            tags: tags,
            requirements: requirements,
            registeredUser:[],
            place: place,
            limit: limit,
            comments: [],
            waitlist:[],
            admin: admin,
            state: state

        }

        const newInsertInformation = await eventsCollection.insertOne(newEvent);
        const newId = newInsertInformation.insertedId;
        return await this.getEventById(newId);
    }
}

module.exports = exportedMethods